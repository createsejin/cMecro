Please read the Issues section of the Contributing Rules at the "contributing" link to the right before submitting an issue report.
